# -*- coding: utf-8 -*-
# from .function import coupled_logarithm as log, \
#                       coupled_exponential as exp, \
#                       coupled_entropy as entropy, \
#                       coupled_cross_entropy as cross_entropy, \
#                       coupled_kl_divergence as kl_divergence, \
#                       tsallis_entropy, shannon_entropy